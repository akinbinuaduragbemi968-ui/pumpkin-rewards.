const base = import.meta.env.BASE_URL;

export default function Slide1() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg text-text">
      <img
        src={base + "iridescent-bubbles.png"}
        crossOrigin="anonymous"
        className="absolute inset-0 h-full w-full object-cover"
        alt="Iridescent holographic bubble cluster"
      />
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-[linear-gradient(180deg,rgba(5,5,10,0.02)_10%,rgba(5,5,10,0.20)_48%,rgba(5,5,10,0.96)_100%)]"
      />
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-[linear-gradient(90deg,rgba(5,5,10,0.38)_0%,rgba(5,5,10,0.08)_60%,rgba(5,5,10,0.02)_100%)]"
      />
      <div className="absolute inset-x-[6vw] bottom-[8vh] z-10 flex items-end justify-between gap-[4vw] border-t border-primary/25 pt-[3vh]">
        <h1 className="max-w-[49vw] text-balance font-display text-[8vw] font-bold leading-[0.9] tracking-[-0.07em] text-white">
          Halloween Airdrop
        </h1>
        <p className="max-w-[26vw] pb-[0.8vh] font-body text-[1.6vw] leading-[1.5] text-white/80">
          A Telegram Mini App for campaign tasks, referrals, points, and test-only USDT simulations.
        </p>
      </div>
    </div>
  );
}
