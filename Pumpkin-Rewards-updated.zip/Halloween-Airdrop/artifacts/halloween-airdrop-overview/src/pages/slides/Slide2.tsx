export default function Slide2() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg text-text">
      <div aria-hidden="true" className="absolute -right-[11vw] top-[11vh] h-[38vw] w-[38vw] rounded-full border border-primary/15" />
      <div aria-hidden="true" className="absolute -right-[6vw] top-[17vh] h-[28vw] w-[28vw] rounded-full border border-accent/10" />
      <main className="relative z-10 flex h-full flex-col px-[6vw] pb-[8vh] pt-[8vh]">
        <h2 className="max-w-[89vw] text-balance font-display text-[3.7vw] font-bold leading-[1.05] tracking-[-0.045em] text-white">
          Campaign participation, in one Telegram flow
        </h2>
        <div className="mt-[4vh] flex flex-1 flex-col justify-between pb-[1vh]">
          <div className="grid grid-cols-[0.35vw_1fr] items-start gap-[1.6vw] border-b border-white/10 py-[1.4vh]">
            <span aria-hidden="true" className="mt-[1.2vh] h-[3.4vh] w-[0.3vw] rounded-full bg-primary" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Home brings profile, season points, test balance, and recent activity together.</p>
          </div>
          <div className="grid grid-cols-[0.35vw_1fr] items-start gap-[1.6vw] border-b border-white/10 py-[1.4vh]">
            <span aria-hidden="true" className="mt-[1.2vh] h-[3.4vh] w-[0.3vw] rounded-full bg-accent" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Tasks support daily check-ins and admin-configured Join or Follow challenges.</p>
          </div>
          <div className="grid grid-cols-[0.35vw_1fr] items-start gap-[1.6vw] border-b border-white/10 py-[1.4vh]">
            <span aria-hidden="true" className="mt-[1.2vh] h-[3.4vh] w-[0.3vw] rounded-full bg-primary/70" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Join and Follow claims may wait for campaign-team review.</p>
          </div>
          <div className="grid grid-cols-[0.35vw_1fr] items-start gap-[1.6vw] border-b border-white/10 py-[1.4vh]">
            <span aria-hidden="true" className="mt-[1.2vh] h-[3.4vh] w-[0.3vw] rounded-full bg-accent/75" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Personal referral codes create Telegram startapp links for inviting friends.</p>
          </div>
          <div className="grid grid-cols-[0.35vw_1fr] items-start gap-[1.6vw] py-[1.4vh]">
            <span aria-hidden="true" className="mt-[1.2vh] h-[3.4vh] w-[0.3vw] rounded-full bg-primary/55" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Wallet and Withdraw save a TRC20 address and submit simulated requests.</p>
          </div>
        </div>
      </main>
    </div>
  );
}
