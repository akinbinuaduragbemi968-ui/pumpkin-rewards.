export default function Slide3() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg text-text">
      <div aria-hidden="true" className="absolute inset-y-[18vh] right-0 w-[42vw] bg-[radial-gradient(ellipse_at_75%_50%,rgba(184,169,212,0.16),transparent_68%)]" />
      <main className="relative z-10 flex h-full flex-col px-[6vw] pb-[8vh] pt-[8vh]">
        <h2 className="max-w-[88vw] text-balance font-display text-[4vw] font-bold leading-[1.02] tracking-[-0.045em] text-white">
          Admins control the campaign loop
        </h2>
        <section className="mt-[4vh] grid h-[62vh] grid-cols-2 grid-rows-[1fr_1fr_auto] gap-x-[3vw] gap-y-[2.4vh] rounded-[1.7vw] border border-primary/15 bg-primary/[0.06] p-[3vw]">
          <div className="flex flex-col justify-center border-t border-primary/30 pt-[1.7vh]">
            <span aria-hidden="true" className="mb-[1.5vh] block h-[0.35vw] w-[3.2vw] bg-accent/75" />
            <p className="font-body text-[2vw] leading-[1.35] text-white/85">Create and edit task prompts, destinations, daily limits, and points.</p>
          </div>
          <div className="flex flex-col justify-center border-t border-primary/30 pt-[1.7vh]">
            <span aria-hidden="true" className="mb-[1.5vh] block h-[0.35vw] w-[3.2vw] bg-primary" />
            <p className="font-body text-[2vw] leading-[1.35] text-white/85">Set test-USDT rewards and a simulated campaign pool.</p>
          </div>
          <div className="flex flex-col justify-center border-t border-primary/30 pt-[1.7vh]">
            <span aria-hidden="true" className="mb-[1.5vh] block h-[0.35vw] w-[3.2vw] bg-primary/75" />
            <p className="font-body text-[2vw] leading-[1.35] text-white/85">Review social-task claims before rewards are applied.</p>
          </div>
          <div className="flex flex-col justify-center border-t border-primary/30 pt-[1.7vh]">
            <span aria-hidden="true" className="mb-[1.5vh] block h-[0.35vw] w-[3.2vw] bg-accent/60" />
            <p className="font-body text-[2vw] leading-[1.35] text-white/85">Review test withdrawal requests; approval records no transfer.</p>
          </div>
          <div className="col-span-2 flex items-start gap-[1.6vw] border-t border-primary/30 pt-[2vh]">
            <span aria-hidden="true" className="mt-[1.1vh] h-[0.35vw] w-[3.2vw] shrink-0 bg-primary/70" />
            <p className="font-body text-[2vw] leading-[1.35] text-white/85">Verified Telegram accounts, referrals, and activity persist in PostgreSQL.</p>
          </div>
        </section>
      </main>
    </div>
  );
}
