export default function Slide5() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg text-text">
      <div aria-hidden="true" className="absolute -right-[10vw] top-[15vh] h-[43vw] w-[43vw] rounded-full border border-primary/15" />
      <div aria-hidden="true" className="absolute -right-[2vw] top-[24vh] h-[28vw] w-[28vw] rounded-full border border-accent/10" />
      <div aria-hidden="true" className="absolute inset-y-0 right-0 w-[34vw] bg-[radial-gradient(ellipse_at_90%_52%,rgba(184,169,212,0.12),transparent_70%)]" />
      <main className="relative z-10 flex h-full flex-col px-[6vw] pb-[8vh] pt-[8vh]">
        <h2 className="max-w-[84vw] text-balance font-display text-[5.2vw] font-bold leading-[0.98] tracking-[-0.055em] text-white">
          Test mode by design
        </h2>
        <p className="mt-[4.5vh] max-w-[88vw] font-display text-[2.3vw] font-medium leading-[1.28] text-primary">
          All balances, points, and rewards are simulated—not promises of allocation.
        </p>
        <div className="mt-[2.5vh] flex flex-1 flex-col justify-between pb-[1vh]">
          <div className="grid grid-cols-[0.35vw_1fr] items-start gap-[1.6vw] border-b border-white/10 py-[1.35vh]">
            <span aria-hidden="true" className="mt-[1.3vh] h-[2.8vh] w-[0.3vw] rounded-full bg-accent" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Test withdrawals are review records; they never send USDT or call a blockchain.</p>
          </div>
          <div className="grid grid-cols-[0.35vw_1fr] items-start gap-[1.6vw] border-b border-white/10 py-[1.35vh]">
            <span aria-hidden="true" className="mt-[1.3vh] h-[2.8vh] w-[0.3vw] rounded-full bg-primary" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Production test reward pool starts at zero.</p>
          </div>
          <div className="grid grid-cols-[0.35vw_1fr] items-start gap-[1.6vw] border-b border-white/10 py-[1.35vh]">
            <span aria-hidden="true" className="mt-[1.3vh] h-[2.8vh] w-[0.3vw] rounded-full bg-accent/75" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Real payout integration remains disabled until funded and configured.</p>
          </div>
          <div className="grid grid-cols-[0.35vw_1fr] items-start gap-[1.6vw] py-[1.35vh]">
            <span aria-hidden="true" className="mt-[1.3vh] h-[2.8vh] w-[0.3vw] rounded-full bg-primary/70" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Next: publish the app and set its Mini App URL in BotFather.</p>
          </div>
        </div>
      </main>
    </div>
  );
}
