export default function Slide4() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg text-text">
      <svg aria-hidden="true" viewBox="0 0 360 420" className="absolute right-[2vw] top-[17vh] h-[55vh] w-[32vw] text-primary opacity-[0.12]">
        <path d="M180 18 314 68v116c0 98-52 165-134 218C98 349 46 282 46 184V68L180 18Z" fill="none" stroke="currentColor" strokeWidth="4" />
        <path d="m111 203 47 47 92-102" fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="8" />
        <path d="M180 46v314" fill="none" stroke="currentColor" strokeDasharray="5 14" strokeWidth="2" />
      </svg>
      <main className="relative z-10 h-full px-[6vw] pb-[8vh] pt-[8vh]">
        <h2 className="max-w-[82vw] text-balance font-display text-[4vw] font-bold leading-[1.02] tracking-[-0.045em] text-white">
          Security starts on the server
        </h2>
        <div className="mt-[5vh] max-w-[88vw] space-y-[2.2vh]">
          <div className="grid grid-cols-[0.7vw_1fr] items-start gap-[1.6vw] border-b border-white/10 pb-[1.8vh]">
            <span aria-hidden="true" className="mt-[1.5vh] h-[0.55vw] w-[0.55vw] rotate-45 border border-accent" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Validate Telegram-signed initData with the bot token—not client profile fields.</p>
          </div>
          <div className="grid grid-cols-[0.7vw_1fr] items-start gap-[1.6vw] border-b border-white/10 pb-[1.8vh]">
            <span aria-hidden="true" className="mt-[1.5vh] h-[0.55vw] w-[0.55vw] rotate-45 border border-primary" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Reject invalid or expired identity payloads and protect account routes.</p>
          </div>
          <div className="grid grid-cols-[0.7vw_1fr] items-start gap-[1.6vw] border-b border-white/10 pb-[1.8vh]">
            <span aria-hidden="true" className="mt-[1.5vh] h-[0.55vw] w-[0.55vw] rotate-45 border border-accent/75" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Restrict production admin access to the configured Telegram ID allowlist.</p>
          </div>
          <div className="grid grid-cols-[0.7vw_1fr] items-start gap-[1.6vw] border-b border-white/10 pb-[1.8vh]">
            <span aria-hidden="true" className="mt-[1.5vh] h-[0.55vw] w-[0.55vw] rotate-45 border border-primary/80" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Validate TRC20 addresses before saving them.</p>
          </div>
          <div className="grid grid-cols-[0.7vw_1fr] items-start gap-[1.6vw]">
            <span aria-hidden="true" className="mt-[1.5vh] h-[0.55vw] w-[0.55vw] rotate-45 border border-accent/65" />
            <p className="font-body text-[2vw] leading-[1.3] text-white/85">Store accounts, balances, tasks, referrals, and activity in PostgreSQL.</p>
          </div>
        </div>
      </main>
    </div>
  );
}
