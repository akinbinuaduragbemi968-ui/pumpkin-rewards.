import { type FormEvent, type ReactNode, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  Activity, ArrowDownToLine, ArrowRight, BadgeCheck, Check, CheckCircle2, CircleHelp,
  Clock3, Copy, ExternalLink, Ghost, Gift, History, House, Link2, LoaderCircle,
  LockKeyhole, Plus, Send, Shield, Sparkles, Star, Users, Wallet,
  X, Zap,
} from 'lucide-react';
import {
  type AirdropBootstrap, type AirdropUser, type AdminDashboard, type AirdropTask,
  type ActivityItem, type TaskInput, type TaskClaim, type Withdrawal,
  setAuthTokenGetter, useCreateAirdropSession, useGetAirdropBootstrap,
  useGetAirdropActivity, useClaimAirdropTask, useSaveAirdropWallet,
  useRequestAirdropWithdrawal, useGetAirdropAdminDashboard, useCreateAirdropTask,
  useUpdateAirdropTask, useReviewAirdropClaim, useReviewAirdropWithdrawal,
  useUpdateAirdropSettings, getGetAirdropBootstrapQueryKey,
  getGetAirdropActivityQueryKey, getGetAirdropAdminDashboardQueryKey,
} from '@workspace/api-client-react';
import {
  Link, Route, Router as WouterRouter, Switch, useLocation,
} from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

declare global {
  interface Window {
    Telegram?: { WebApp?: { initData?: string; ready?: () => void; expand?: () => void } };
  }
}

const queryClient = new QueryClient();
const getTelegramInitData = () => window.Telegram?.WebApp?.initData ?? '';
setAuthTokenGetter(() => getTelegramInitData() || (import.meta.env.DEV ? 'DEV_DEMO' : null));

const navItems = [
  { href: '/', label: 'Home', icon: House },
  { href: '/tasks', label: 'Tasks', icon: Sparkles },
  { href: '/referrals', label: 'Invite', icon: Users },
  { href: '/wallet', label: 'Wallet', icon: Wallet },
  { href: '/withdraw', label: 'Request', icon: ArrowDownToLine },
  { href: '/account', label: 'Account', icon: Activity },
];

function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return (
    <div className="app-shell">
      <header className="topbar">
        <Link href="/" className="brand" data-testid="link-home">
          <span className="brand-mark"><Ghost size={20} strokeWidth={2.2} /></span>
          <span>Pumpkin <span style={{ color: 'var(--orange)' }}>Rewards</span></span>
        </Link>
        <div className="top-meta"><span className="live-dot" /> Pumpkin Rewards season</div>
      </header>
      <div style={{ minHeight: 12 }} />
      {children}
      <nav className="bottom-nav" aria-label="Main navigation">
        {navItems.map(({ href, label, icon: Icon }) => (
          <Link key={href} href={href} className={`nav-item ${location === href ? 'active' : ''}`} data-testid={`link-nav-${label.toLowerCase()}`}>
            <Icon /><span>{label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}

function LoadingPage() {
  return <div className="page">
    <div className="skeleton" style={{ height: 12, width: 115, margin: '26px 0 15px' }} />
    <div className="skeleton" style={{ height: 42, width: '68%', marginBottom: 10 }} />
    <div className="skeleton" style={{ height: 18, width: '84%' }} />
    <div className="skeleton" style={{ height: 210, marginTop: 25, borderRadius: 24 }} />
    <div className="skeleton" style={{ height: 130, marginTop: 15, borderRadius: 18 }} />
    <p className="status-line" style={{ textAlign: 'center', marginTop: 16 }}>Warming up the night…</p>
  </div>;
}

function EmptyState({ icon: Icon = CircleHelp, title, copy }: { icon?: typeof Ghost; title: string; copy: string }) {
  return <div className="panel empty">
    <div className="empty-mark"><Icon size={21} /></div>
    <div className="empty-title">{title}</div>
    <p className="empty-copy">{copy}</p>
  </div>;
}

function statusBadge(status: string) {
  if (status === 'approved' || status === 'approved_test') return <span className="badge green"><Check size={11} /> Approved</span>;
  if (status === 'rejected') return <span className="badge red"><X size={11} /> Not approved</span>;
  if (status === 'pending' || status === 'pending_test') return <span className="badge orange"><Clock3 size={11} /> Pending review</span>;
  return <span className="badge">{status}</span>;
}

function formatDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? 'Recently' : new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(date);
}

function ActivityRow({ item }: { item: ActivityItem }) {
  return <div className="activity-row" data-testid={`activity-item-${item.id}`}>
    <div className="activity-symbol"><History size={16} /></div>
    <div className="activity-main">
      <div className="activity-title">{item.title}</div>
      <div className="activity-detail">{item.details || item.kind}</div>
    </div>
    <div className="activity-amount">{item.amount > 0 ? `+${item.amount}` : item.amount}<span className="activity-date">{formatDate(item.createdAt)}</span></div>
  </div>;
}

function AppContent() {
  const [location] = useLocation();
  const queryClient = useQueryClient();
  const initData = getTelegramInitData();
  const devDemo = import.meta.env.DEV && !initData;
  const createSession = useCreateAirdropSession();
  const sessionMutateRef = useRef(createSession.mutate);
  sessionMutateRef.current = createSession.mutate;
  const sessionAttempted = useRef(false);
  const [toast, setToast] = useState('');
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const notify = (message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 3200);
  };

  useEffect(() => {
    window.Telegram?.WebApp?.ready?.();
    window.Telegram?.WebApp?.expand?.();
    if (sessionAttempted.current || (!initData && !import.meta.env.DEV)) return;
    sessionAttempted.current = true;
    sessionMutateRef.current({ data: { initData } }, {
      onSuccess: (bootstrap) => queryClient.setQueryData(getGetAirdropBootstrapQueryKey(), bootstrap),
    });
  }, [initData, queryClient]);

  const bootstrapQuery = useGetAirdropBootstrap({
    query: { queryKey: getGetAirdropBootstrapQueryKey(), enabled: createSession.isSuccess, staleTime: 15_000 },
  });
  const bootstrap = bootstrapQuery.data ?? createSession.data;
  const activityQuery = useGetAirdropActivity({
    query: { queryKey: getGetAirdropActivityQueryKey(), enabled: createSession.isSuccess },
  });
  const user = bootstrap?.user;
  const isAdmin = Boolean(user?.isAdmin);
  const adminQuery = useGetAirdropAdminDashboard({
    query: { queryKey: getGetAirdropAdminDashboardQueryKey(), enabled: isAdmin },
  });

  const invalidate = async (admin = false) => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: getGetAirdropBootstrapQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getGetAirdropActivityQueryKey() }),
      ...(admin ? [queryClient.invalidateQueries({ queryKey: getGetAirdropAdminDashboardQueryKey() })] : []),
    ]);
  };
  if (!initData && !import.meta.env.DEV) return <Layout><TelegramUnavailable /></Layout>;
  if (createSession.isPending || (createSession.isSuccess && !bootstrap && bootstrapQuery.isLoading)) return <Layout><LoadingPage /></Layout>;
  if (!createSession.isSuccess && !createSession.isError) return <Layout><LoadingPage /></Layout>;
  if (createSession.isError || (bootstrapQuery.isError && !bootstrap)) {
    return <Layout><ErrorState onRetry={() => {
      sessionAttempted.current = false;
      createSession.mutate({ data: { initData } }, { onSuccess: (data) => queryClient.setQueryData(getGetAirdropBootstrapQueryKey(), data) });
    }} /></Layout>;
  }
  if (!user || !bootstrap) return <Layout><LoadingPage /></Layout>;

  return <>
    {toast ? <div role="status" className="toast">{toast}</div> : null}
    <Layout>
      {devDemo ? <div className="notice notice-purple" style={{ marginTop: 13 }}><CircleHelp size={16} /> Development demo mode. Telegram identity is not verified here; balances and rewards remain test-only.</div> : null}
      <div className="notice" style={{ marginTop: devDemo ? 10 : 15 }} data-testid="banner-test-only">
        <Zap size={15} /><span><strong>Test mode only.</strong> All balances, points and rewards are simulated. No real airdrop or payout is promised.</span>
      </div>
      <Switch>
        <Route path="/" component={() => <HomePage bootstrap={bootstrap} activities={activityQuery.data ?? bootstrap.recentActivity ?? []} activityLoading={activityQuery.isLoading} />} />
        <Route path="/tasks" component={() => <TasksPage tasks={bootstrap.tasks ?? []} notify={notify} afterClaim={() => invalidate()} />} />
        <Route path="/referrals" component={() => <ReferralPage user={user} referralLink={bootstrap.referralLink} notify={notify} />} />
        <Route path="/wallet" component={() => <WalletPage address={user.walletAddress ?? ''} notify={notify} afterSave={() => invalidate()} />} />
        <Route path="/withdraw" component={() => <WithdrawPage balance={user.testUsdtBalance} walletAddress={user.walletAddress} minimum={bootstrap.settings.minimumWithdrawal} notify={notify} afterRequest={() => invalidate()} />} />
        <Route path="/account" component={() => <AccountPage user={user} activities={activityQuery.data ?? bootstrap.recentActivity ?? []} loading={activityQuery.isLoading} />} />
        <Route path="/admin" component={() => <AdminPage isAdmin={isAdmin} dashboard={adminQuery.data} isLoading={adminQuery.isLoading} isError={adminQuery.isError} onRetry={() => adminQuery.refetch()} notify={notify} afterChange={() => invalidate(true)} />} />
        <Route component={NotFound} />
      </Switch>
      {isAdmin && location !== '/admin' ? <Link href="/admin" className="admin-shortcut" data-testid="link-admin-shortcut"><Shield size={15} /> Admin tools</Link> : null}
    </Layout>
  </>;
}

function ErrorState({ onRetry }: { onRetry: () => void }) {
  return <div className="unavailable"><div className="unavailable-inner">
    <div className="unavailable-orbit"><CircleHelp size={28} /></div>
    <div className="eyebrow">Connection lost</div>
    <h1 className="page-title">Couldn’t reach the drop</h1>
    <p className="subcopy">Your account data lives on the campaign server. Check your connection and try again.</p>
    <button className="button button-primary" style={{ marginTop: 20 }} onClick={onRetry} data-testid="button-retry"><Activity size={15} /> Try again</button>
  </div></div>;
}

function TelegramUnavailable() {
  return <div className="unavailable"><div className="unavailable-inner">
    <div className="unavailable-orbit"><Send size={27} /></div>
    <div className="eyebrow">A Telegram mini app</div>
    <h1 className="page-title">Open this in Telegram</h1>
    <p className="subcopy">Pumpkin Rewards needs Telegram’s signed Mini App session to securely load your account. Open it from the official bot in Telegram.</p>
    <div className="notice notice-purple" style={{ marginTop: 20, textAlign: 'left' }}><LockKeyhole size={15} /> Signed Telegram identity is required. This page will not ask you to paste account or wallet credentials.</div>
  </div></div>;
}

function PageHeading({ eyebrow, title, copy }: { eyebrow: string; title: string; copy: string }) {
  return <div className="page" style={{ paddingTop: 24 }}>
    <div className="eyebrow">{eyebrow}</div><h1 className="page-title">{title}</h1><p className="subcopy">{copy}</p>
  </div>;
}

function HomePage({ bootstrap, activities, activityLoading }: { bootstrap: AirdropBootstrap; activities: ActivityItem[]; activityLoading: boolean }) {
  const { user } = bootstrap;
  const initials = user.displayName.trim().split(/\s+/).slice(0, 2).map((word) => word[0]).join('').toUpperCase() || 'N';
  return <main className="page">
    <section className="hero-card" data-testid="card-account-overview">
      <div className="hero-top">
        <div className="user-identity"><div className="avatar">{initials}</div><div><div style={{ fontWeight: 700, fontSize: 14 }}>{user.displayName}</div><div className="status-line">{user.username ? `@${user.username}` : 'Your Pumpkin Rewards season account'}</div></div></div>
        {user.isVerified ? <span className="verified"><BadgeCheck size={15} /> Verified</span> : <span className="badge">Seasonal account</span>}
      </div>
      <div className="balance-label">Season points · test only</div>
      <div className="balance-value" data-testid="text-points-balance">{user.points.toLocaleString()} <small>PTS</small></div>
      <div className="balance-foot">Points are campaign demo values, not a promise of token allocation.</div>
      <div className="stat-strip">
        <div className="stat-cell"><div className="stat-number">{Number(user.testUsdtBalance).toFixed(2)}</div><div className="stat-label">Test USDT</div></div>
        <div className="stat-cell"><div className="stat-number">{user.referralCount}</div><div className="stat-label">Invited friends</div></div>
        <div className="stat-cell"><div className="stat-number">{bootstrap.tasks.filter((task) => task.active).length}</div><div className="stat-label">Open tasks</div></div>
      </div>
    </section>
    <div className="home-columns" style={{ marginTop: 26 }}>
      <section>
        <div className="section-head"><div><div className="eyebrow">Find your way</div><h2 className="section-title" style={{ marginTop: 6 }}>Tonight’s shortcuts</h2></div></div>
        <div className="quick-grid">
          <QuickLink href="/tasks" icon={Sparkles} title="Daily tasks" sub="Collect test points" />
          <QuickLink href="/referrals" icon={Users} title="Bring your circle" sub={`${user.referralCount} invited so far`} />
          <QuickLink href="/wallet" icon={Wallet} title="TRC20 wallet" sub={user.walletAddress ? 'Address saved' : 'Set up an address'} />
          <QuickLink href="/withdraw" icon={ArrowDownToLine} title="Test request" sub="No blockchain transfer" />
        </div>
      </section>
      <section>
        <div className="section-head"><div><div className="eyebrow">The paper trail</div><h2 className="section-title" style={{ marginTop: 6 }}>Recent activity</h2></div><Link href="/account" className="section-note">View all <ArrowRight size={12} style={{ verticalAlign: 'middle' }} /></Link></div>
        <div className="panel" style={{ padding: '0 15px' }}>
          {activityLoading ? <div style={{ padding: 15 }}><div className="skeleton" style={{ height: 42 }} /></div> :
            activities.length ? <div className="row-list">{activities.slice(0, 4).map((item) => <ActivityRow key={item.id} item={item} />)}</div> :
              <EmptyState icon={History} title="A quiet night so far" copy="Task claims and account updates will show up here." />}
        </div>
      </section>
    </div>
    <div className="notice notice-purple" style={{ marginTop: 22 }}><Shield size={15} /> Keep your wallet details private. Pumpkin Rewards never needs your seed phrase or private key.</div>
  </main>;
}

function QuickLink({ href, icon: Icon, title, sub }: { href: string; icon: typeof Ghost; title: string; sub: string }) {
  return <Link href={href} className="quick-link">
    <span className="quick-icon"><Icon size={17} /></span><span className="quick-copy"><span className="quick-title">{title}</span><span className="quick-sub" style={{ display: 'block' }}>{sub}</span></span><ArrowRight size={15} color="#82758e" />
  </Link>;
}

function TasksPage({ tasks, notify, afterClaim }: { tasks: AirdropTask[]; notify: (message: string) => void; afterClaim: () => Promise<void> }) {
  const claim = useClaimAirdropTask();
  const activeTasks = tasks.filter((task) => task.active);
  const doClaim = (task: AirdropTask) => {
    if (task.targetUrl) {
      window.open(task.targetUrl, '_blank', 'noopener,noreferrer');
      notify('Task link opened. Verification may be pending after your visit.');
    }
    claim.mutate({ taskId: task.id }, { onSuccess: async (result) => {
      notify(result.status === 'approved' ? `Claim recorded: +${result.rewardPoints} test points${result.testUsdtReward > 0 ? ` and ${result.testUsdtReward} test USDT` : ''}.` : 'Claim submitted. Verification may be pending.');
      await afterClaim();
    }, onError: () => notify('Could not submit this claim. Please try again.') });
  };
  return <main>
    <PageHeading eyebrow="A little mischief, a little progress" title="Tasks for tonight" copy="Choose a challenge, visit its destination, then send your claim for review." />
    <div className="notice notice-purple" style={{ marginTop: 20 }}><Clock3 size={15} /> Social tasks open their configured destination. Verification may remain pending until reviewed.</div>
    <div className="section-head"><h2 className="section-title">Open challenges</h2><span className="badge orange">{activeTasks.length} available</span></div>
    {activeTasks.length ? <div className="task-list">{activeTasks.map((task) => <TaskCard key={task.id} task={task} busy={claim.isPending} onClaim={() => doClaim(task)} />)}</div> :
      <EmptyState icon={Sparkles} title="No open tasks yet" copy="The campaign team hasn’t posted a challenge. Check back later." />}
    {claim.isError ? <p className="helper" style={{ color: '#f0a4a4', marginTop: 12 }}>Your claim could not be submitted. Nothing was deducted.</p> : null}
    <div className="section-head"><h2 className="section-title">How claims work</h2></div>
    <div className="panel" style={{ padding: 16 }}>
      <div style={{ display: 'flex', gap: 11, alignItems: 'flex-start' }}><span className="quick-icon"><CheckCircle2 size={17} /></span><div><strong style={{ fontSize: 12 }}>Submit, then wait for review</strong><p className="helper" style={{ margin: '5px 0 0' }}>A claim is a request for test points. Status is controlled by the campaign server and may be pending.</p></div></div>
    </div>
  </main>;
}

function TaskCard({ task, busy, onClaim }: { task: AirdropTask; busy: boolean; onClaim: () => void }) {
  const Icon = task.taskType === 'join' ? Users : task.taskType === 'follow' ? ExternalLink : Star;
  return <article className="panel task-card" data-testid={`card-task-${task.id}`}>
    <div className="task-glyph"><Icon size={19} /></div>
    <div className="task-content">
      <h3 className="task-title">{task.title}</h3><p className="task-description">{task.description}</p>
      <div className="task-footer"><span className="reward">+{task.rewardPoints} test points{task.testUsdtReward > 0 ? ` · +${task.testUsdtReward} test USDT` : ''}</span><button className="button button-primary button-small" onClick={onClaim} disabled={busy} data-testid={`button-claim-task-${task.id}`}>{busy ? <LoaderCircle size={13} /> : task.targetUrl ? <ExternalLink size={13} /> : <Check size={13} />}{task.taskType === 'join' ? 'Join & claim' : task.taskType === 'follow' ? 'Follow & claim' : 'Complete'}</button></div>
    </div>
  </article>;
}

function ReferralPage({ user, referralLink, notify }: { user: AirdropUser; referralLink: string | null; notify: (message: string) => void }) {
  const copy = async () => {
    if (!referralLink) { notify('Invite link is unavailable until the bot username is configured.'); return; }
    try { await navigator.clipboard.writeText(referralLink); notify('Invite link copied.'); }
    catch { notify('Copy is unavailable in this browser. Select and copy the link manually.'); }
  };
  const share = async () => {
    if (!referralLink) { notify('Invite link is unavailable until the bot username is configured.'); return; }
    if (navigator.share) {
      try { await navigator.share({ title: 'Pumpkin Rewards', text: 'Join me in the Pumpkin Rewards season tasks.', url: referralLink }); }
      catch { /* User cancelled the native share sheet. */ }
    } else copy();
  };
  return <main>
    <PageHeading eyebrow="Bring your circle" title="A link with your name on it" copy="Invite friends to take part in the seasonal campaign. Referral counts and any rewards are managed server-side." />
    <section className="hero-card" style={{ marginTop: 23 }}>
      <div className="eyebrow">Your invite mark</div>
      <div style={{ marginTop: 10, font: '600 33px var(--font-display)', letterSpacing: '-.06em' }}>{user.referralCode}</div>
      <p className="subcopy" style={{ marginTop: 6 }}>Personal code · {user.referralCount} joined</p>
      <div className="referral-box"><Link2 size={15} color="#c28aff" /><span className="referral-url" data-testid="text-referral-link">{referralLink || 'Invite link not available'}</span><button className="button button-secondary button-small" onClick={copy} disabled={!referralLink} data-testid="button-copy-referral"><Copy size={13} /> Copy</button></div>
      <button className="button button-primary" style={{ marginTop: 12, width: '100%' }} onClick={share} disabled={!referralLink} data-testid="button-share-referral"><Send size={15} /> Share invite</button>
    </section>
    <div className="section-head"><h2 className="section-title">A fair heads-up</h2></div>
    <div className="notice notice-purple"><Shield size={16} /> Sharing is optional. Referral counts and rewards are not guaranteed and are subject to campaign review. Never promise friends a payout.</div>
    <div className="panel" style={{ padding: 17, marginTop: 14 }}>
      <div style={{ display: 'flex', gap: 12 }}><div className="quick-icon"><Users size={17} /></div><div><div className="activity-title">Your invited circle</div><div className="activity-detail" style={{ whiteSpace: 'normal', marginTop: 5 }}>People who join using your invite are reflected here when the server confirms them.</div></div></div>
      <div className="divider" /><div className="stat-number">{user.referralCount} <span className="stat-label">confirmed invites</span></div>
    </div>
  </main>;
}

function WalletPage({ address, notify, afterSave }: { address: string; notify: (message: string) => void; afterSave: () => Promise<void> }) {
  const [value, setValue] = useState(address);
  const save = useSaveAirdropWallet();
  useEffect(() => setValue(address), [address]);
  const submit = (event: FormEvent) => {
    event.preventDefault();
    const candidate = value.trim();
    if (candidate.length !== 34 || !candidate.startsWith('T')) { notify('Enter a valid-looking 34-character TRON address starting with T.'); return; }
    save.mutate({ data: { walletAddress: candidate } }, { onSuccess: async () => {
      notify('TRC20 address saved.'); await afterSave();
    }, onError: () => notify('Address could not be saved. Check it and try again.') });
  };
  return <main>
    <PageHeading eyebrow="Account setup" title="Your TRC20 address" copy="Save the destination address for test-mode request records. This does not connect a wallet or move funds." />
    <form className="panel" onSubmit={submit} style={{ padding: 18, marginTop: 22 }}>
      <div className="notice notice-purple"><LockKeyhole size={15} /> Never enter a seed phrase or private key. We only store the public address you provide.</div>
      <div className="field"><label htmlFor="wallet-address">TRON address (TRC20)</label><input id="wallet-address" className="input mono" value={value} onChange={(event) => setValue(event.target.value)} placeholder="T…" maxLength={34} autoComplete="off" data-testid="input-wallet-address" /><span className="helper">A TRON address is 34 characters and starts with T.</span></div>
      <button className="button button-primary" type="submit" disabled={save.isPending} data-testid="button-save-wallet">{save.isPending ? <LoaderCircle size={15} /> : <Check size={15} />}{address ? 'Update address' : 'Save address'}</button>
      {address ? <div style={{ marginTop: 18 }}><div className="section-note" style={{ marginBottom: 8 }}>Currently saved</div><div className="wallet-lockup"><Wallet size={15} color="#c28aff" /><span className="wallet-address">{address}</span><BadgeCheck size={14} color="#a8d99e" /></div></div> : null}
    </form>
    <div className="notice" style={{ marginTop: 14 }}><Zap size={15} /> The address is only attached to a test withdrawal request. No blockchain transfer is available.</div>
  </main>;
}

function WithdrawPage({ balance, walletAddress, minimum, notify, afterRequest }: { balance: number; walletAddress: string | null; minimum: number; notify: (message: string) => void; afterRequest: () => Promise<void> }) {
  const [amount, setAmount] = useState('');
  const request = useRequestAirdropWithdrawal();
  const parsedAmount = Number(amount);
  const tooSmall = amount !== '' && parsedAmount < minimum;
  const overBalance = amount !== '' && parsedAmount > balance;
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!walletAddress) { notify('Add a TRC20 address before making a test request.'); return; }
    if (!Number.isFinite(parsedAmount) || parsedAmount <= 0 || parsedAmount < minimum || parsedAmount > balance) return;
    request.mutate({ data: { amount: parsedAmount } }, { onSuccess: async () => {
      setAmount(''); notify('Test request submitted for review. No funds were transferred.'); await afterRequest();
    }, onError: () => notify('Test request could not be submitted.') });
  };
  return <main>
    <PageHeading eyebrow="Simulated balance" title="Request a test withdrawal" copy="This creates a test-mode review record only. It never sends a blockchain transaction." />
    <section className="hero-card" style={{ marginTop: 22, padding: 20 }}>
      <div className="eyebrow">Test USDT balance</div><div style={{ marginTop: 9, font: '600 36px var(--font-display)', letterSpacing: '-.06em' }} data-testid="text-test-balance">{Number(balance).toFixed(2)} <span style={{ color: 'var(--orange)', font: '500 12px var(--font-mono)' }}>USDT · TEST</span></div>
      <div className="balance-foot">Minimum test request: {Number(minimum).toFixed(2)} USDT</div>
    </section>
    <form className="panel" onSubmit={submit} style={{ padding: 18, marginTop: 15 }}>
      {!walletAddress ? <div className="notice" style={{ marginBottom: 14 }}><Wallet size={15} /> Add a TRC20 address first. <Link href="/wallet" style={{ color: 'var(--orange)', textDecoration: 'underline' }}>Set up wallet</Link></div> :
        <div className="wallet-lockup" style={{ marginBottom: 14 }}><Wallet size={15} color="#c28aff" /><span className="wallet-address">{walletAddress}</span><span className="badge">TRC20</span></div>}
      <div className="field"><label htmlFor="withdraw-amount">Amount to request · test USDT</label><input id="withdraw-amount" className="input" type="number" min={minimum} max={balance} step="0.01" inputMode="decimal" placeholder={Number(minimum).toFixed(2)} value={amount} onChange={(event) => setAmount(event.target.value)} data-testid="input-withdraw-amount" />
        {tooSmall ? <span className="helper" style={{ color: '#ffb477' }}>Below the {Number(minimum).toFixed(2)} minimum.</span> : null}
        {overBalance ? <span className="helper" style={{ color: '#f0a4a4' }}>This is above your available test balance.</span> : null}
      </div>
      <div className="notice"><Shield size={15} /><span><strong>Test request only.</strong> A request enters review as a simulated record. Approved test requests are not a payment or blockchain transfer.</span></div>
      <button type="submit" className="button button-primary" style={{ width: '100%', marginTop: 15 }} disabled={request.isPending || !walletAddress || !amount || tooSmall || overBalance} data-testid="button-request-withdrawal">{request.isPending ? <LoaderCircle size={15} /> : <ArrowDownToLine size={15} />} Submit test request</button>
    </form>
  </main>;
}

function AccountPage({ user, activities, loading }: { user: AirdropUser; activities: ActivityItem[]; loading: boolean }) {
  return <main>
    <PageHeading eyebrow="Your corner of the night" title="Account & activity" copy="Your profile details and server-recorded activity for this seasonal campaign." />
    <section className="panel" style={{ padding: 17, marginTop: 21 }}>
      <div className="user-identity"><div className="avatar">{user.displayName.trim().charAt(0).toUpperCase()}</div><div><div style={{ fontWeight: 700, fontSize: 14 }}>{user.displayName}</div><div className="status-line">{user.username ? `@${user.username}` : 'Telegram participant'}</div></div></div>
      <div className="divider" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 13 }}>
        <Info label="Telegram ID" value={user.telegramId} mono /><Info label="Referral code" value={user.referralCode} mono />
        <Info label="Points · test" value={user.points.toLocaleString()} /><Info label="Invited friends" value={String(user.referralCount)} />
        <Info label="Identity check" value={user.isVerified ? 'Verified' : 'Not verified'} /><Info label="TRC20 address" value={user.walletAddress ? `${user.walletAddress.slice(0, 6)}…${user.walletAddress.slice(-5)}` : 'Not set'} mono />
      </div>
    </section>
    <div className="section-head"><div><div className="eyebrow">Account ledger</div><h2 className="section-title" style={{ marginTop: 5 }}>Activity</h2></div><span className="badge">{activities.length} records</span></div>
    <div className="panel" style={{ padding: '0 15px' }}>
      {loading ? <div style={{ padding: 16 }}><div className="skeleton" style={{ height: 42 }} /></div> :
        activities.length ? <div className="row-list">{activities.map((item) => <ActivityRow key={item.id} item={item} />)}</div> :
          <EmptyState icon={History} title="No account activity yet" copy="Once you participate, your campaign history will be recorded here." />}
    </div>
    <p className="helper" style={{ marginTop: 12 }}>All balances and rewards shown in this app are test-only.</p>
  </main>;
}

function Info({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return <div><div className="section-note">{label}</div><div style={{ marginTop: 4, fontSize: 12, fontFamily: mono ? 'var(--font-mono)' : undefined, overflowWrap: 'anywhere' }}>{value}</div></div>;
}

type AdminTab = 'tasks' | 'claims' | 'withdrawals' | 'settings';
const blankTask: TaskInput = { title: '', description: '', taskType: 'complete', targetUrl: null, rewardPoints: 25, testUsdtReward: 0, active: true, dailyLimit: false };

function AdminPage({ isAdmin, dashboard, isLoading, isError, onRetry, notify, afterChange }: {
  isAdmin: boolean; dashboard: AdminDashboard | undefined;
  isLoading: boolean; isError: boolean; onRetry: () => void; notify: (message: string) => void; afterChange: () => Promise<void>;
}) {
  const [tab, setTab] = useState<AdminTab>('tasks');
  const [editing, setEditing] = useState<AirdropTask | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<TaskInput>(blankTask);
  const [pool, setPool] = useState('');
  const [minimum, setMinimum] = useState('');
  const createTask = useCreateAirdropTask();
  const updateTask = useUpdateAirdropTask();
  const reviewClaim = useReviewAirdropClaim();
  const reviewWithdrawal = useReviewAirdropWithdrawal();
  const updateSettings = useUpdateAirdropSettings();
  useEffect(() => {
    if (dashboard) { setPool(String(dashboard.settings.testPoolUsdt)); setMinimum(String(dashboard.settings.minimumWithdrawal)); }
  }, [dashboard?.settings.testPoolUsdt, dashboard?.settings.minimumWithdrawal]);
  if (!isAdmin) return <main><PageHeading eyebrow="Restricted area" title="Admin access only" copy="This review desk is available to campaign administrators." /><div className="notice" style={{ marginTop: 20 }}><LockKeyhole size={15} /> Your Telegram account does not have administrator access.</div></main>;
  if (isLoading) return <main><PageHeading eyebrow="Campaign desk" title="Loading review queue" copy="Checking the campaign controls…" /><div className="skeleton" style={{ height: 190, marginTop: 22 }} /></main>;
  if (isError || !dashboard) return <main><PageHeading eyebrow="Campaign desk" title="Admin controls unavailable" copy="Could not retrieve the server-owned campaign dashboard." /><button className="button button-primary" onClick={onRetry} style={{ marginTop: 18 }} data-testid="button-retry-admin">Retry</button></main>;
  const mutateDone = async (msg: string) => { notify(msg); await afterChange(); };
  const beginEdit = (task?: AirdropTask) => {
    setEditing(task ?? null);
    setForm(task ? { title: task.title, description: task.description, taskType: task.taskType, targetUrl: task.targetUrl, rewardPoints: task.rewardPoints, testUsdtReward: task.testUsdtReward, active: task.active, dailyLimit: task.dailyLimit } : blankTask);
    setShowForm(true);
  };
  const submitTask = (event: FormEvent) => {
    event.preventDefault();
    const payload = { ...form, title: form.title.trim(), description: form.description.trim(), targetUrl: form.targetUrl?.trim() || null, rewardPoints: Number(form.rewardPoints), testUsdtReward: Number(form.testUsdtReward) };
    const options = { onSuccess: async () => { setShowForm(false); await mutateDone(editing ? 'Task updated.' : 'Task created.'); }, onError: () => notify('Task could not be saved.') };
    if (editing) updateTask.mutate({ taskId: editing.id, data: payload }, options);
    else createTask.mutate({ data: payload }, options);
  };
  const review = (claim: TaskClaim, status: 'approved' | 'rejected') => reviewClaim.mutate({ claimId: claim.id, data: { status } }, { onSuccess: () => { void mutateDone(`Claim ${status}.`); }, onError: () => notify('Claim review failed.') });
  const decideWithdrawal = (withdrawal: Withdrawal, status: 'approved_test' | 'rejected') => reviewWithdrawal.mutate({ withdrawalId: withdrawal.id, data: { status } }, { onSuccess: () => { void mutateDone(status === 'approved_test' ? 'Test request approved. No transfer was made.' : 'Test request rejected.'); }, onError: () => notify('Request review failed.') });
  const saveSettings = (event: FormEvent) => {
    event.preventDefault();
    const testPoolUsdt = Number(pool); const minimumWithdrawal = Number(minimum);
    if (!Number.isFinite(testPoolUsdt) || testPoolUsdt < 0 || !Number.isFinite(minimumWithdrawal) || minimumWithdrawal < .01) { notify('Enter valid campaign values.'); return; }
    updateSettings.mutate({ data: { testPoolUsdt, minimumWithdrawal } }, { onSuccess: () => { void mutateDone('Test settings saved.'); }, onError: () => notify('Settings were not saved.') });
  };
  return <main>
    <PageHeading eyebrow="Campaign desk" title="Night operations" copy="Server-owned controls for tasks, claim review and test requests." />
    <div className="stat-strip panel" style={{ padding: '15px 0', marginTop: 19 }}>
      <div className="stat-cell"><div className="stat-number">{dashboard.userCount}</div><div className="stat-label">Participants</div></div>
      <div className="stat-cell"><div className="stat-number">{dashboard.pendingClaims.length}</div><div className="stat-label">Claims in queue</div></div>
      <div className="stat-cell"><div className="stat-number">{dashboard.withdrawals.filter((w) => w.status === 'pending_test').length}</div><div className="stat-label">Test requests</div></div>
    </div>
    <div className="notice" style={{ marginTop: 14 }}><Shield size={15} /> Admin approvals update simulated records only. No withdrawal review triggers a blockchain transaction.</div>
    <div className="admin-tabs" style={{ marginTop: 17 }} role="tablist">
      {(['tasks', 'claims', 'withdrawals', 'settings'] as AdminTab[]).map((key) => <button key={key} className={`admin-tab ${tab === key ? 'active' : ''}`} onClick={() => setTab(key)} role="tab" aria-selected={tab === key} data-testid={`tab-admin-${key}`}>{key === 'tasks' ? 'Tasks' : key === 'claims' ? `Claims · ${dashboard.pendingClaims.length}` : key === 'withdrawals' ? 'Test requests' : 'Settings'}</button>)}
    </div>
    {tab === 'tasks' ? <section>
      <div className="section-head"><h2 className="section-title">Task library</h2><button className="button button-primary button-small" onClick={() => beginEdit()} data-testid="button-new-task"><Plus size={13} /> Add task</button></div>
      {showForm ? <form className="panel" onSubmit={submitTask} style={{ padding: 16, marginBottom: 13 }}>
        <div className="section-title">{editing ? 'Edit task' : 'New task'}</div>
        <div className="field"><label htmlFor="task-title">Title</label><input id="task-title" className="input" maxLength={120} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required data-testid="input-task-title" /></div>
        <div className="field"><label htmlFor="task-desc">Description</label><textarea id="task-desc" className="input" maxLength={500} rows={3} style={{ paddingTop: 12 }} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} data-testid="input-task-description" /></div>
        <div className="settings-grid">
          <div className="field"><label htmlFor="task-type">Type</label><select id="task-type" className="input" value={form.taskType} onChange={(e) => setForm({ ...form, taskType: e.target.value as TaskInput['taskType'] })} data-testid="select-task-type"><option value="join">Join</option><option value="follow">Follow</option><option value="complete">Complete</option></select></div>
          <div className="field"><label htmlFor="task-reward">Reward points · test</label><input id="task-reward" className="input" type="number" min="0" max="1000000" value={form.rewardPoints} onChange={(e) => setForm({ ...form, rewardPoints: Number(e.target.value) })} data-testid="input-task-reward" /></div>
        </div>
        <div className="field"><label htmlFor="task-usdt-reward">Test USDT reward</label><input id="task-usdt-reward" className="input" type="number" min="0" max="1000000" step="0.000001" value={form.testUsdtReward} onChange={(e) => setForm({ ...form, testUsdtReward: Number(e.target.value) })} data-testid="input-task-usdt-reward" /><span className="helper">Test-only credit drawn from the simulated pool; never a real payout.</span></div>
        <div className="field"><label htmlFor="task-url">Destination URL</label><input id="task-url" className="input" type="url" value={form.targetUrl ?? ''} onChange={(e) => setForm({ ...form, targetUrl: e.target.value || null })} placeholder="https://" data-testid="input-task-url" /></div>
        <label className="helper" style={{ display: 'flex', gap: 8, margin: '9px 0' }}><input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} data-testid="checkbox-task-active" /> Active and visible to participants</label>
        <label className="helper" style={{ display: 'flex', gap: 8, margin: '9px 0' }}><input type="checkbox" checked={form.dailyLimit} onChange={(e) => setForm({ ...form, dailyLimit: e.target.checked })} data-testid="checkbox-task-daily" /> Daily limit applies</label>
        <div className="form-actions"><button className="button button-primary" disabled={createTask.isPending || updateTask.isPending} data-testid="button-save-task">Save task</button><button type="button" className="button button-quiet" onClick={() => setShowForm(false)}>Cancel</button></div>
      </form> : null}
      {dashboard.tasks.length ? dashboard.tasks.map((task) => <article className="panel admin-item" key={task.id} data-testid={`admin-task-${task.id}`}>
        <div className="admin-item-top"><div><div className="admin-item-name">{task.title}</div><div className="admin-item-description">{task.description}</div></div><span className={`badge ${task.active ? 'green' : ''}`}>{task.active ? 'Active' : 'Paused'}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}><span className="reward">+{task.rewardPoints} test points · {task.testUsdtReward} test USDT · {task.taskType}</span><div className="admin-actions"><button className="button button-secondary button-small" onClick={() => beginEdit(task)} data-testid={`button-edit-task-${task.id}`}>Edit</button><button className="button button-quiet button-small" onClick={() => updateTask.mutate({ taskId: task.id, data: { title: task.title, description: task.description, taskType: task.taskType, targetUrl: task.targetUrl, rewardPoints: task.rewardPoints, testUsdtReward: task.testUsdtReward, active: !task.active, dailyLimit: task.dailyLimit } }, { onSuccess: () => { void mutateDone(task.active ? 'Task paused.' : 'Task activated.'); }, onError: () => notify('Task status was not changed.') })} data-testid={`button-toggle-task-${task.id}`}>{task.active ? 'Pause' : 'Activate'}</button></div></div>
      </article>) : <EmptyState icon={Gift} title="No campaign tasks" copy="Create a task to make it available to participants." />}
    </section> : null}
    {tab === 'claims' ? <section><div className="section-head"><h2 className="section-title">Claim review</h2><span className="badge orange">{dashboard.pendingClaims.length} pending</span></div>
      {dashboard.pendingClaims.length ? dashboard.pendingClaims.map((claim) => <ClaimReviewCard key={claim.id} claim={claim} busy={reviewClaim.isPending} onReview={(status) => review(claim, status)} />) : <EmptyState icon={CheckCircle2} title="Queue is clear" copy="No participant claims need review right now." />}
    </section> : null}
    {tab === 'withdrawals' ? <section><div className="section-head"><h2 className="section-title">Test request review</h2><span className="badge orange">{dashboard.withdrawals.filter((w) => w.status === 'pending_test').length} pending</span></div>
      {dashboard.withdrawals.length ? dashboard.withdrawals.map((withdrawal) => <WithdrawalReviewCard key={withdrawal.id} withdrawal={withdrawal} busy={reviewWithdrawal.isPending} onReview={(status) => decideWithdrawal(withdrawal, status)} />) : <EmptyState icon={ArrowDownToLine} title="No test requests" copy="Submitted test-mode requests will appear here for review." />}
    </section> : null}
    {tab === 'settings' ? <form className="panel" onSubmit={saveSettings} style={{ marginTop: 20, padding: 17 }}>
      <div className="eyebrow">Campaign parameters</div><h2 className="section-title" style={{ marginTop: 6 }}>Test settings</h2>
      <div className="notice" style={{ marginTop: 13 }}><Zap size={15} /> Test mode is always on for this interface. These controls do not enable real payments.</div>
      <div className="field"><label htmlFor="settings-pool">Simulated pool · test USDT</label><input id="settings-pool" className="input" type="number" min="0" step="0.01" value={pool} onChange={(e) => setPool(e.target.value)} data-testid="input-test-pool" /></div>
      <div className="field"><label htmlFor="settings-minimum">Minimum test request · USDT</label><input id="settings-minimum" className="input" type="number" min=".01" step="0.01" value={minimum} onChange={(e) => setMinimum(e.target.value)} data-testid="input-minimum-withdrawal" /></div>
      <div className="status-line">Payment integration: {dashboard.settings.paymentIntegrationReady ? 'reported ready by server' : 'not configured'} · test mode: {dashboard.settings.testMode ? 'on' : 'off'}</div>
      <button type="submit" className="button button-primary" style={{ marginTop: 15 }} disabled={updateSettings.isPending} data-testid="button-save-settings">{updateSettings.isPending ? 'Saving…' : 'Save test settings'}</button>
    </form> : null}
  </main>;
}

function ClaimReviewCard({ claim, busy, onReview }: { claim: TaskClaim; busy: boolean; onReview: (status: 'approved' | 'rejected') => void }) {
  return <article className="panel admin-item" data-testid={`admin-claim-${claim.id}`}>
    <div className="admin-item-top"><div><div className="admin-item-name">{claim.taskTitle}</div><div className="admin-item-description">Claim #{claim.id} · submitted {formatDate(claim.claimedAt)}</div></div>{statusBadge(claim.status)}</div>
    <div className="task-footer"><span className="reward">+{claim.rewardPoints} test points</span>{claim.status === 'pending' ? <div className="admin-actions"><button className="button button-secondary button-small" onClick={() => onReview('approved')} disabled={busy} data-testid={`button-approve-claim-${claim.id}`}>Approve</button><button className="button button-danger button-small" onClick={() => onReview('rejected')} disabled={busy} data-testid={`button-reject-claim-${claim.id}`}>Reject</button></div> : null}</div>
  </article>;
}

function WithdrawalReviewCard({ withdrawal, busy, onReview }: { withdrawal: Withdrawal; busy: boolean; onReview: (status: 'approved_test' | 'rejected') => void }) {
  return <article className="panel admin-item" data-testid={`admin-withdrawal-${withdrawal.id}`}>
    <div className="admin-item-top"><div><div className="admin-item-name">{Number(withdrawal.amount).toFixed(2)} USDT <span className="badge orange">TEST ONLY</span></div><div className="admin-item-description">Request #{withdrawal.id} · {formatDate(withdrawal.createdAt)}</div></div>{statusBadge(withdrawal.status)}</div>
    <div className="wallet-lockup" style={{ marginBottom: 12 }}><Wallet size={14} color="#c28aff" /><span className="wallet-address">{withdrawal.walletAddress}</span></div>
    {withdrawal.testMode ? <div className="helper" style={{ marginBottom: 12 }}>Test mode request. Approval records a simulated outcome; no transfer occurs.</div> : null}
    {withdrawal.status === 'pending_test' ? <div className="admin-actions"><button className="button button-secondary button-small" onClick={() => onReview('approved_test')} disabled={busy} data-testid={`button-approve-withdrawal-${withdrawal.id}`}>Approve test</button><button className="button button-danger button-small" onClick={() => onReview('rejected')} disabled={busy} data-testid={`button-reject-withdrawal-${withdrawal.id}`}>Reject</button></div> : null}
  </article>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
        <RoutedErrorBoundary><AppContent /></RoutedErrorBoundary>
      </WouterRouter>
      <Toaster />
    </TooltipProvider>
  </QueryClientProvider>;
}

export default App;
