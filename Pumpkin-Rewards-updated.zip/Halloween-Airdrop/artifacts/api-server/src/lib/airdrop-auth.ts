import { createHmac, timingSafeEqual } from "node:crypto";

export interface TelegramIdentity {
  id: string;
  firstName: string;
  lastName?: string;
  username?: string;
  languageCode?: string;
  startParam?: string;
}

const MAX_INIT_DATA_AGE_SECONDS = 24 * 60 * 60;
const MAX_FUTURE_SKEW_SECONDS = 5 * 60;

export function validateTelegramInitData(
  rawInitData: string,
): TelegramIdentity | null {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  if (!botToken || !rawInitData || rawInitData.length > 4096) return null;

  const params = new URLSearchParams(rawInitData);
  const entries = [...params.entries()];
  if (entries.length === 0 || new Set(entries.map(([key]) => key)).size !== entries.length) {
    return null;
  }

  const suppliedHash = params.get("hash");
  const authDate = Number(params.get("auth_date"));
  if (
    !suppliedHash ||
    !/^[0-9a-f]{64}$/i.test(suppliedHash) ||
    !Number.isInteger(authDate)
  ) {
    return null;
  }

  const nowSeconds = Math.floor(Date.now() / 1000);
  if (
    nowSeconds - authDate > MAX_INIT_DATA_AGE_SECONDS ||
    authDate - nowSeconds > MAX_FUTURE_SKEW_SECONDS
  ) {
    return null;
  }

  const dataCheckString = entries
    .filter(([key]) => key !== "hash")
    .sort(([left], [right]) => (left < right ? -1 : left > right ? 1 : 0))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");
  const secretKey = createHmac("sha256", "WebAppData")
    .update(botToken)
    .digest();
  const expectedHash = createHmac("sha256", secretKey)
    .update(dataCheckString)
    .digest();
  const actualHash = Buffer.from(suppliedHash, "hex");
  if (
    actualHash.length !== expectedHash.length ||
    !timingSafeEqual(actualHash, expectedHash)
  ) {
    return null;
  }

  const rawUser = params.get("user");
  if (!rawUser) return null;

  try {
    const user: unknown = JSON.parse(rawUser);
    if (!user || typeof user !== "object") return null;
    const value = user as Record<string, unknown>;
    const id = value["id"];
    const firstName = value["first_name"];
    if (
      (typeof id !== "number" && typeof id !== "string") ||
      !/^\d+$/.test(String(id)) ||
      typeof firstName !== "string" ||
      firstName.length === 0 ||
      firstName.length > 128
    ) {
      return null;
    }

    return {
      id: String(id),
      firstName,
      ...(typeof value["last_name"] === "string"
        ? { lastName: value["last_name"].slice(0, 128) }
        : {}),
      ...(typeof value["username"] === "string"
        ? { username: value["username"].slice(0, 64) }
        : {}),
      ...(typeof value["language_code"] === "string"
        ? { languageCode: value["language_code"].slice(0, 16) }
        : {}),
      ...(params.get("start_param")
        ? { startParam: params.get("start_param")! }
        : {}),
    };
  } catch {
    return null;
  }
}

export function developmentDemoIdentity(): TelegramIdentity | null {
  if (process.env.NODE_ENV === "production") return null;
  return {
    id: "demo-preview",
    firstName: "Halloween",
    lastName: "Demo",
    username: "demo_preview",
  };
}

export function identityFromAuthorization(
  authorization: string | undefined,
): { identity: TelegramIdentity; isDemo: boolean } | null {
  if (authorization?.startsWith("Bearer ")) {
    const token = authorization.slice("Bearer ".length);
    if (token === "DEV_DEMO") {
      const identity = developmentDemoIdentity();
      return identity ? { identity, isDemo: true } : null;
    }
    const identity = validateTelegramInitData(token);
    return identity ? { identity, isDemo: false } : null;
  }
  return null;
}
