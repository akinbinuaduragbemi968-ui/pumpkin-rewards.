import { randomBytes } from "node:crypto";
import { count, desc, eq } from "drizzle-orm";
import {
  airdropActivityTable,
  airdropCampaignSettingsTable,
  airdropTasksTable,
  airdropUsersTable,
  db,
} from "@workspace/db";
import type { TelegramIdentity } from "./airdrop-auth";

export interface RequestAccount {
  identity: TelegramIdentity;
  user: typeof airdropUsersTable.$inferSelect;
  isDemo: boolean;
}

let cachedBotUsername: string | null | undefined;

export async function ensureAirdropDefaults(): Promise<void> {
  await db.insert(airdropCampaignSettingsTable)
    .values({
      id: "main",
      testPoolUsdt: process.env.NODE_ENV === "production" ? 0 : 100,
      minimumWithdrawal: 1,
    })
    .onConflictDoNothing();

  await db.insert(airdropTasksTable).values([
    {
      title: "Daily haunted check-in",
      description: "Complete this daily check-in to earn test points.",
      taskType: "complete",
      targetUrl: null,
      rewardPoints: 25,
      testUsdtReward: 0,
      active: true,
      dailyLimit: true,
    },
    {
      title: "Join the Telegram community",
      description: "Add your real Telegram channel URL in Admin before enabling.",
      taskType: "join",
      targetUrl: null,
      rewardPoints: 0,
      testUsdtReward: 0,
      active: false,
      dailyLimit: true,
    },
    {
      title: "Follow campaign updates",
      description: "Add a verified updates URL in Admin before enabling.",
      taskType: "follow",
      targetUrl: null,
      rewardPoints: 0,
      testUsdtReward: 0,
      active: false,
      dailyLimit: true,
    },
  ]).onConflictDoNothing();
}

async function findReferrer(startParam: string | undefined, newUserId: string) {
  if (!startParam || startParam.length > 64) return null;
  const [referrer] = await db.select({ telegramId: airdropUsersTable.telegramId })
    .from(airdropUsersTable)
    .where(eq(airdropUsersTable.referralCode, startParam))
    .limit(1);
  return referrer && referrer.telegramId !== newUserId
    ? referrer.telegramId
    : null;
}

export async function getOrCreateAirdropUser(
  identity: TelegramIdentity,
  isDemo: boolean,
) {
  const [existing] = await db.select()
    .from(airdropUsersTable)
    .where(eq(airdropUsersTable.telegramId, identity.id))
    .limit(1);
  if (existing) {
    const [updated] = await db.update(airdropUsersTable).set({
      firstName: identity.firstName,
      lastName: identity.lastName ?? null,
      username: identity.username ?? null,
      languageCode: identity.languageCode ?? null,
    }).where(eq(airdropUsersTable.telegramId, identity.id)).returning();
    return updated ?? existing;
  }

  const referralCode = randomBytes(6).toString("hex").toUpperCase();
  const referredBy = await findReferrer(identity.startParam, identity.id);
  const [created] = await db.insert(airdropUsersTable).values({
    telegramId: identity.id,
    firstName: identity.firstName,
    lastName: identity.lastName ?? null,
    username: identity.username ?? null,
    languageCode: identity.languageCode ?? null,
    referralCode,
    referredBy,
    points: 0,
    // Only the isolated development preview gets a clearly labeled sample balance.
    testUsdtBalance: isDemo ? 25 : 0,
  }).onConflictDoNothing().returning();

  if (created) {
    if (referredBy) {
      await db.insert(airdropActivityTable).values({
        telegramId: referredBy,
        title: "New referral",
        details: "A Telegram-verified user joined with your referral link.",
        kind: "referral",
        amount: 0,
      });
    }
    return created;
  }

  const [raced] = await db.select()
    .from(airdropUsersTable)
    .where(eq(airdropUsersTable.telegramId, identity.id))
    .limit(1);
  if (!raced) throw new Error("Could not create or retrieve the Telegram account");
  return raced;
}

export async function getRequestAccount(
  identity: TelegramIdentity,
  isDemo: boolean,
): Promise<RequestAccount> {
  await ensureAirdropDefaults();
  const user = await getOrCreateAirdropUser(identity, isDemo);
  return { identity, user, isDemo };
}

export function isAirdropAdmin(account: RequestAccount): boolean {
  if (account.isDemo && process.env.NODE_ENV !== "production") return true;
  const admins = (process.env.TELEGRAM_ADMIN_IDS ?? "")
    .split(",")
    .map((id) => id.trim())
    .filter(Boolean);
  return admins.includes(account.identity.id);
}

export async function getReferralLink(referralCode: string): Promise<string | null> {
  const configuredUsername = process.env.TELEGRAM_BOT_USERNAME?.replace(/^@/, "");
  if (configuredUsername && /^[A-Za-z0-9_]{5,32}$/.test(configuredUsername)) {
    return `https://t.me/${configuredUsername}?startapp=${encodeURIComponent(referralCode)}`;
  }

  if (cachedBotUsername == null) {
    cachedBotUsername = null;
    const token = process.env.TELEGRAM_BOT_TOKEN;
    if (!token) return null;
    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/getMe`, {
        signal: AbortSignal.timeout(5000),
      });
      if (!response.ok) return null;
      const payload: unknown = await response.json();
      if (!payload || typeof payload !== "object") return null;
      const result = (payload as Record<string, unknown>)["result"];
      if (!result || typeof result !== "object") return null;
      const username = (result as Record<string, unknown>)["username"];
      if (typeof username === "string" && /^[A-Za-z0-9_]{5,32}$/.test(username)) {
        cachedBotUsername = username;
      }
    } catch {
      // A username can be configured later; authentication and the rest of the app remain available.
      return null;
    }
  }

  return cachedBotUsername
    ? `https://t.me/${cachedBotUsername}?startapp=${encodeURIComponent(referralCode)}`
    : null;
}

export async function makeBootstrap(account: RequestAccount) {
  const [referrals, tasks, activity, settings] = await Promise.all([
    db.select({ value: count() })
      .from(airdropUsersTable)
      .where(eq(airdropUsersTable.referredBy, account.user.telegramId)),
    db.select().from(airdropTasksTable).orderBy(airdropTasksTable.id),
    db.select().from(airdropActivityTable)
      .where(eq(airdropActivityTable.telegramId, account.user.telegramId))
      .orderBy(desc(airdropActivityTable.createdAt))
      .limit(12),
    db.select().from(airdropCampaignSettingsTable)
      .where(eq(airdropCampaignSettingsTable.id, "main"))
      .limit(1),
  ]);
  const config = settings[0];
  const displayName = [account.user.firstName, account.user.lastName]
    .filter(Boolean)
    .join(" ");

  return {
    user: {
      telegramId: account.user.telegramId,
      displayName: displayName || "Telegram user",
      username: account.user.username,
      points: account.user.points,
      testUsdtBalance: account.user.testUsdtBalance,
      walletAddress: account.user.walletAddress,
      referralCode: account.user.referralCode,
      referralCount: Number(referrals[0]?.value ?? 0),
      isAdmin: isAirdropAdmin(account),
      isVerified: !account.isDemo,
    },
    tasks: tasks.map((task) => ({
      id: task.id,
      title: task.title,
      description: task.description,
      taskType: task.taskType,
      targetUrl: task.targetUrl,
      rewardPoints: task.rewardPoints,
      testUsdtReward: task.testUsdtReward,
      active: task.active,
      dailyLimit: task.dailyLimit,
    })),
    referralLink: await getReferralLink(account.user.referralCode),
    recentActivity: activity.map((item) => ({
      id: item.id,
      title: item.title,
      details: item.details,
      kind: item.kind,
      amount: item.amount,
      createdAt: item.createdAt,
    })),
    settings: {
      testMode: true,
      testPoolUsdt: config?.testPoolUsdt ?? 0,
      minimumWithdrawal: config?.minimumWithdrawal ?? 1,
      paymentIntegrationReady: false,
    },
  };
}

export async function getRecentActivity(telegramId: string) {
  return db.select().from(airdropActivityTable)
    .where(eq(airdropActivityTable.telegramId, telegramId))
    .orderBy(desc(airdropActivityTable.createdAt))
    .limit(50);
}
