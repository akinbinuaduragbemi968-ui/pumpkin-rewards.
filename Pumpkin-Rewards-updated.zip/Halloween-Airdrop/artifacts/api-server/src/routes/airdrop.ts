import { Router, type IRouter, type Request, type Response } from "express";
import { and, count, desc, eq, gte, sql } from "drizzle-orm";
import {
  airdropActivityTable,
  airdropCampaignSettingsTable,
  airdropTaskClaimsTable,
  airdropTasksTable,
  airdropUsersTable,
  airdropWithdrawalsTable,
  db,
} from "@workspace/db";
import {
  ClaimAirdropTaskParams,
  ClaimAirdropTaskResponse,
  CreateAirdropSessionBody,
  GetAirdropActivityResponse,
  GetAirdropBootstrapResponse,
  RequestAirdropWithdrawalBody,
  RequestAirdropWithdrawalResponse,
  SaveAirdropWalletBody,
  SaveAirdropWalletResponse,
} from "@workspace/api-zod";
import {
  developmentDemoIdentity,
  identityFromAuthorization,
  validateTelegramInitData,
} from "../lib/airdrop-auth";
import {
  getRecentActivity,
  getRequestAccount,
  isAirdropAdmin,
  makeBootstrap,
} from "../lib/airdrop-service";
import { isValidTrc20Address } from "../lib/tron-address";
import airdropAdminRouter from "./airdrop-admin";

const router: IRouter = Router();

async function currentAccount(
  req: Request,
  res: Response,
) {
  const authenticated = identityFromAuthorization(req.get("authorization") ?? undefined);
  if (!authenticated) {
    res.status(401).json({ error: "Open the Mini App through Telegram to continue." });
    return null;
  }
  return getRequestAccount(authenticated.identity, authenticated.isDemo);
}

function isUniqueConflict(error: unknown): boolean {
  return Boolean(
    error &&
      typeof error === "object" &&
      "code" in error &&
      (error as { code?: unknown }).code === "23505",
  );
}

router.post("/airdrop/session", async (req, res): Promise<void> => {
  const parsed = CreateAirdropSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid session request." });
    return;
  }

  const isDemo = parsed.data.initData.length === 0;
  const identity = isDemo
    ? developmentDemoIdentity()
    : validateTelegramInitData(parsed.data.initData);
  if (!identity) {
    res.status(401).json({
      error:
        process.env.NODE_ENV === "production"
          ? "Telegram identity could not be verified. Open this Mini App in Telegram."
          : "Telegram initData is invalid or expired.",
    });
    return;
  }

  const account = await getRequestAccount(identity, isDemo);
  res.json(GetAirdropBootstrapResponse.parse(await makeBootstrap(account)));
});

router.get("/airdrop/bootstrap", async (req, res): Promise<void> => {
  const account = await currentAccount(req, res);
  if (!account) return;
  res.json(GetAirdropBootstrapResponse.parse(await makeBootstrap(account)));
});

router.get("/airdrop/activity", async (req, res): Promise<void> => {
  const account = await currentAccount(req, res);
  if (!account) return;
  const activity = await getRecentActivity(account.user.telegramId);
  res.json(
    GetAirdropActivityResponse.parse(
      activity.map((item) => ({
        id: item.id,
        title: item.title,
        details: item.details,
        kind: item.kind,
        amount: item.amount,
        createdAt: item.createdAt,
      })),
    ),
  );
});

router.post("/airdrop/tasks/:taskId/claims", async (req, res): Promise<void> => {
  const account = await currentAccount(req, res);
  if (!account) return;
  const params = ClaimAirdropTaskParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid task." });
    return;
  }

  const [task] = await db.select()
    .from(airdropTasksTable)
    .where(eq(airdropTasksTable.id, params.data.taskId))
    .limit(1);
  if (!task || !task.active) {
    res.status(404).json({ error: "This task is not available." });
    return;
  }
  if (task.taskType !== "complete" && !task.targetUrl) {
    res.status(409).json({ error: "This task has no verified destination yet." });
    return;
  }

  const today = new Date().toISOString().slice(0, 10);
  const claimDay = task.dailyLimit ? today : "1970-01-01";
  try {
    const result = await db.transaction(async (tx) => {
      const [existing] = await tx.select({ id: airdropTaskClaimsTable.id })
        .from(airdropTaskClaimsTable)
        .where(and(
          eq(airdropTaskClaimsTable.telegramId, account.user.telegramId),
          eq(airdropTaskClaimsTable.taskId, task.id),
          eq(airdropTaskClaimsTable.claimDay, claimDay),
        ))
        .limit(1);
      if (existing) return { kind: "duplicate" as const };

      const automaticallyApproved = task.taskType === "complete";
      if (automaticallyApproved && task.testUsdtReward > 0) {
        const [pool] = await tx.update(airdropCampaignSettingsTable)
          .set({
            testPoolUsdt: sql`${airdropCampaignSettingsTable.testPoolUsdt} - ${task.testUsdtReward}`,
          })
          .where(and(
            eq(airdropCampaignSettingsTable.id, "main"),
            gte(airdropCampaignSettingsTable.testPoolUsdt, task.testUsdtReward),
          ))
          .returning({ testPoolUsdt: airdropCampaignSettingsTable.testPoolUsdt });
        if (!pool) return { kind: "pool" as const };
      }

      const [claim] = await tx.insert(airdropTaskClaimsTable).values({
        telegramId: account.user.telegramId,
        taskId: task.id,
        taskTitle: task.title,
        status: automaticallyApproved ? "approved" : "pending",
        rewardPoints: task.rewardPoints,
        testUsdtReward: task.testUsdtReward,
        claimDay,
      }).returning();

      if (automaticallyApproved) {
        await tx.update(airdropUsersTable).set({
          points: sql`${airdropUsersTable.points} + ${task.rewardPoints}`,
          testUsdtBalance: sql`${airdropUsersTable.testUsdtBalance} + ${task.testUsdtReward}`,
        }).where(eq(airdropUsersTable.telegramId, account.user.telegramId));
        await tx.insert(airdropActivityTable).values({
          telegramId: account.user.telegramId,
          title: "Task completed",
          details: task.title,
          kind: "task",
          amount: task.rewardPoints,
        });
        if (task.testUsdtReward > 0) {
          await tx.insert(airdropActivityTable).values({
            telegramId: account.user.telegramId,
            title: "Test USDT reward",
            details: `${task.title}. Test-only; not redeemable.`,
            kind: "test_reward",
            amount: task.testUsdtReward,
          });
        }
      }

      return { kind: "created" as const, claim };
    });

    if (result.kind === "duplicate") {
      res.status(409).json({ error: "This task was already claimed for today." });
      return;
    }
    if (result.kind === "pool") {
      res.status(409).json({ error: "The test reward pool does not have enough balance." });
      return;
    }
    const claim = result.claim;
    res.status(201).json(
      ClaimAirdropTaskResponse.parse({
        id: claim.id,
        taskId: claim.taskId,
        taskTitle: claim.taskTitle,
        telegramId: account.user.telegramId,
        displayName: [account.user.firstName, account.user.lastName].filter(Boolean).join(" "),
        status: claim.status,
        rewardPoints: claim.rewardPoints,
        testUsdtReward: claim.testUsdtReward,
        claimedAt: claim.claimedAt,
      }),
    );
  } catch (error) {
    if (isUniqueConflict(error)) {
      res.status(409).json({ error: "This task was already claimed for today." });
      return;
    }
    throw error;
  }
});

router.put("/airdrop/wallet", async (req, res): Promise<void> => {
  const account = await currentAccount(req, res);
  if (!account) return;
  const parsed = SaveAirdropWalletBody.safeParse(req.body);
  if (!parsed.success || !isValidTrc20Address(parsed.data.walletAddress)) {
    res.status(400).json({ error: "Enter a valid TRC20 wallet address." });
    return;
  }

  const walletAddress = parsed.data.walletAddress;
  const [referrals] = await db.select({ value: count() })
    .from(airdropUsersTable)
    .where(eq(airdropUsersTable.referredBy, account.user.telegramId));
  const [updated] = await db.update(airdropUsersTable)
    .set({ walletAddress })
    .where(eq(airdropUsersTable.telegramId, account.user.telegramId))
    .returning();
  await db.insert(airdropActivityTable).values({
    telegramId: account.user.telegramId,
    title: "Wallet updated",
    details: "Saved a TRC20 address for test-mode requests.",
    kind: "wallet",
    amount: 0,
  });

  res.json(SaveAirdropWalletResponse.parse({
    telegramId: updated.telegramId,
    displayName: [updated.firstName, updated.lastName].filter(Boolean).join(" "),
    username: updated.username,
    points: updated.points,
    testUsdtBalance: updated.testUsdtBalance,
    walletAddress: updated.walletAddress,
    referralCode: updated.referralCode,
    referralCount: Number(referrals?.value ?? 0),
    isAdmin: isAirdropAdmin(account),
    isVerified: !account.isDemo,
  }));
});

router.post("/airdrop/withdrawals", async (req, res): Promise<void> => {
  const account = await currentAccount(req, res);
  if (!account) return;
  const parsed = RequestAirdropWithdrawalBody.safeParse(req.body);
  if (!parsed.success || !Number.isFinite(parsed.data.amount)) {
    res.status(400).json({ error: "Enter a valid withdrawal amount." });
    return;
  }

  const amount = Math.round(parsed.data.amount * 1_000_000) / 1_000_000;
  if (Math.abs(amount - parsed.data.amount) > 0.0000001) {
    res.status(400).json({ error: "Amounts can have up to six decimal places." });
    return;
  }
  if (!account.user.walletAddress || !isValidTrc20Address(account.user.walletAddress)) {
    res.status(400).json({ error: "Save a valid TRC20 wallet address first." });
    return;
  }

  const [settings] = await db.select()
    .from(airdropCampaignSettingsTable)
    .where(eq(airdropCampaignSettingsTable.id, "main"))
    .limit(1);
  if (amount < (settings?.minimumWithdrawal ?? 1)) {
    res.status(400).json({ error: `Minimum test withdrawal is ${settings?.minimumWithdrawal ?? 1} USDT.` });
    return;
  }

  const result = await db.transaction(async (tx) => {
    const [pending] = await tx.select({ id: airdropWithdrawalsTable.id })
      .from(airdropWithdrawalsTable)
      .where(and(
        eq(airdropWithdrawalsTable.telegramId, account.user.telegramId),
        eq(airdropWithdrawalsTable.status, "pending_test"),
      ))
      .limit(1);
    if (pending) return { kind: "pending" as const };

    const [debited] = await tx.update(airdropUsersTable)
      .set({
        testUsdtBalance: sql`${airdropUsersTable.testUsdtBalance} - ${amount}`,
      })
      .where(and(
        eq(airdropUsersTable.telegramId, account.user.telegramId),
        gte(airdropUsersTable.testUsdtBalance, amount),
      ))
      .returning({ telegramId: airdropUsersTable.telegramId });
    if (!debited) return { kind: "balance" as const };

    const [withdrawal] = await tx.insert(airdropWithdrawalsTable).values({
      telegramId: account.user.telegramId,
      amount,
      walletAddress: account.user.walletAddress!,
      status: "pending_test",
      testMode: true,
    }).returning();
    await tx.insert(airdropActivityTable).values({
      telegramId: account.user.telegramId,
      title: "Test withdrawal requested",
      details: "Simulation only. No USDT was sent.",
      kind: "withdrawal",
      amount: -amount,
    });
    return { kind: "created" as const, withdrawal };
  });

  if (result.kind === "pending") {
    res.status(409).json({ error: "You already have a test withdrawal awaiting review." });
    return;
  }
  if (result.kind === "balance") {
    res.status(409).json({ error: "Your test USDT balance is too low." });
    return;
  }

  res.status(201).json(
    RequestAirdropWithdrawalResponse.parse({
      id: result.withdrawal.id,
      telegramId: account.user.telegramId,
      displayName: [account.user.firstName, account.user.lastName].filter(Boolean).join(" "),
      amount: result.withdrawal.amount,
      walletAddress: result.withdrawal.walletAddress,
      status: result.withdrawal.status,
      createdAt: result.withdrawal.createdAt,
      testMode: true,
    }),
  );
});

router.use("/", airdropAdminRouter);

export default router;
