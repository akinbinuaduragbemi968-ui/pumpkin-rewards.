import { Router, type IRouter, type Request, type Response } from "express";
import { and, count, desc, eq, gte, sql } from "drizzle-orm";
import {
  airdropActivityTable,
  airdropCampaignSettingsTable,
  airdropTaskClaimsTable,
  airdropTasksTable,
  airdropUsersTable,
  airdropWithdrawalsTable,
  db,
} from "@workspace/db";
import {
  CreateAirdropTaskBody,
  CreateAirdropTaskResponse,
  GetAirdropAdminDashboardResponse,
  ReviewAirdropClaimBody,
  ReviewAirdropClaimParams,
  ReviewAirdropClaimResponse,
  ReviewAirdropWithdrawalBody,
  ReviewAirdropWithdrawalParams,
  ReviewAirdropWithdrawalResponse,
  UpdateAirdropSettingsBody,
  UpdateAirdropSettingsResponse,
  UpdateAirdropTaskBody,
  UpdateAirdropTaskParams,
  UpdateAirdropTaskResponse,
} from "@workspace/api-zod";
import { identityFromAuthorization } from "../lib/airdrop-auth";
import {
  getRequestAccount,
  isAirdropAdmin,
} from "../lib/airdrop-service";

const router: IRouter = Router();

async function adminAccount(req: Request, res: Response) {
  const authenticated = identityFromAuthorization(req.get("authorization") ?? undefined);
  if (!authenticated) {
    res.status(401).json({ error: "Open the Mini App through Telegram to continue." });
    return null;
  }
  const account = await getRequestAccount(
    authenticated.identity,
    authenticated.isDemo,
  );
  if (!isAirdropAdmin(account)) {
    res.status(403).json({ error: "This Telegram account is not configured as an admin." });
    return null;
  }
  return account;
}

function validTaskUrl(url: string | null, taskType: string, active: boolean) {
  if (!url) return !active || taskType === "complete";
  try {
    return new URL(url).protocol === "https:";
  } catch {
    return false;
  }
}

function validSixDecimalAmount(value: number) {
  return Math.abs(value - Math.round(value * 1_000_000) / 1_000_000) < 0.0000001;
}

function taskPayload(data: {
  id: number;
  title: string;
  description: string;
  taskType: string;
  targetUrl: string | null;
  rewardPoints: number;
  testUsdtReward: number;
  active: boolean;
  dailyLimit: boolean;
}) {
  return {
    id: data.id,
    title: data.title,
    description: data.description,
    taskType: data.taskType,
    targetUrl: data.targetUrl,
    rewardPoints: data.rewardPoints,
    testUsdtReward: data.testUsdtReward,
    active: data.active,
    dailyLimit: data.dailyLimit,
  };
}

router.get("/airdrop/admin", async (req, res): Promise<void> => {
  if (!(await adminAccount(req, res))) return;
  const [tasks, claimRows, withdrawalRows, settingsRows, userRows] =
    await Promise.all([
      db.select().from(airdropTasksTable).orderBy(airdropTasksTable.id),
      db.select({
        id: airdropTaskClaimsTable.id,
        taskId: airdropTaskClaimsTable.taskId,
        taskTitle: airdropTaskClaimsTable.taskTitle,
        telegramId: airdropTaskClaimsTable.telegramId,
        firstName: airdropUsersTable.firstName,
        lastName: airdropUsersTable.lastName,
        status: airdropTaskClaimsTable.status,
        rewardPoints: airdropTaskClaimsTable.rewardPoints,
        testUsdtReward: airdropTaskClaimsTable.testUsdtReward,
        claimedAt: airdropTaskClaimsTable.claimedAt,
      })
        .from(airdropTaskClaimsTable)
        .innerJoin(
          airdropUsersTable,
          eq(airdropUsersTable.telegramId, airdropTaskClaimsTable.telegramId),
        )
        .where(eq(airdropTaskClaimsTable.status, "pending"))
        .orderBy(desc(airdropTaskClaimsTable.claimedAt))
        .limit(100),
      db.select({
        id: airdropWithdrawalsTable.id,
        telegramId: airdropWithdrawalsTable.telegramId,
        firstName: airdropUsersTable.firstName,
        lastName: airdropUsersTable.lastName,
        amount: airdropWithdrawalsTable.amount,
        walletAddress: airdropWithdrawalsTable.walletAddress,
        status: airdropWithdrawalsTable.status,
        createdAt: airdropWithdrawalsTable.createdAt,
        testMode: airdropWithdrawalsTable.testMode,
      })
        .from(airdropWithdrawalsTable)
        .innerJoin(
          airdropUsersTable,
          eq(airdropUsersTable.telegramId, airdropWithdrawalsTable.telegramId),
        )
        .orderBy(desc(airdropWithdrawalsTable.createdAt))
        .limit(100),
      db.select().from(airdropCampaignSettingsTable)
        .where(eq(airdropCampaignSettingsTable.id, "main"))
        .limit(1),
      db.select({ value: count() }).from(airdropUsersTable),
    ]);

  const settings = settingsRows[0];
  res.json(
    GetAirdropAdminDashboardResponse.parse({
      tasks: tasks.map(taskPayload),
      pendingClaims: claimRows.map((claim) => ({
        id: claim.id,
        taskId: claim.taskId,
        taskTitle: claim.taskTitle,
        telegramId: claim.telegramId,
        displayName: [claim.firstName, claim.lastName].filter(Boolean).join(" "),
        status: claim.status,
        rewardPoints: claim.rewardPoints,
        testUsdtReward: claim.testUsdtReward,
        claimedAt: claim.claimedAt,
      })),
      withdrawals: withdrawalRows.map((item) => ({
        id: item.id,
        telegramId: item.telegramId,
        displayName: [item.firstName, item.lastName].filter(Boolean).join(" "),
        amount: item.amount,
        walletAddress: item.walletAddress,
        status: item.status,
        createdAt: item.createdAt,
        testMode: true,
      })),
      settings: {
        testMode: true,
        testPoolUsdt: settings?.testPoolUsdt ?? 0,
        minimumWithdrawal: settings?.minimumWithdrawal ?? 1,
        paymentIntegrationReady: false,
      },
      userCount: Number(userRows[0]?.value ?? 0),
    }),
  );
});

router.post("/airdrop/admin/tasks", async (req, res): Promise<void> => {
  if (!(await adminAccount(req, res))) return;
  const parsed = CreateAirdropTaskBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Check the task fields and try again." });
    return;
  }
  const data = parsed.data;
  if (
    !validTaskUrl(data.targetUrl, data.taskType, data.active) ||
    !validSixDecimalAmount(data.testUsdtReward)
  ) {
    res.status(400).json({ error: "Active social tasks need a valid HTTPS destination." });
    return;
  }
  const [task] = await db.insert(airdropTasksTable)
    .values(data)
    .returning();
  res.status(201).json(CreateAirdropTaskResponse.parse(taskPayload(task)));
});

router.patch("/airdrop/admin/tasks/:taskId", async (req, res): Promise<void> => {
  if (!(await adminAccount(req, res))) return;
  const params = UpdateAirdropTaskParams.safeParse(req.params);
  const parsed = UpdateAirdropTaskBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "Check the task fields and try again." });
    return;
  }
  const data = parsed.data;
  if (
    !validTaskUrl(data.targetUrl, data.taskType, data.active) ||
    !validSixDecimalAmount(data.testUsdtReward)
  ) {
    res.status(400).json({ error: "Active social tasks need a valid HTTPS destination." });
    return;
  }
  const [task] = await db.update(airdropTasksTable)
    .set(data)
    .where(eq(airdropTasksTable.id, params.data.taskId))
    .returning();
  if (!task) {
    res.status(404).json({ error: "Task not found." });
    return;
  }
  res.json(UpdateAirdropTaskResponse.parse(taskPayload(task)));
});

router.patch("/airdrop/admin/claims/:claimId", async (req, res): Promise<void> => {
  if (!(await adminAccount(req, res))) return;
  const params = ReviewAirdropClaimParams.safeParse(req.params);
  const parsed = ReviewAirdropClaimBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "Invalid claim review." });
    return;
  }

  const result = await db.transaction(async (tx) => {
    const [claim] = await tx.select()
      .from(airdropTaskClaimsTable)
      .where(and(
        eq(airdropTaskClaimsTable.id, params.data.claimId),
        eq(airdropTaskClaimsTable.status, "pending"),
      ))
      .limit(1);
    if (!claim) return { kind: "missing" as const };

    if (parsed.data.status === "approved" && claim.testUsdtReward > 0) {
      const [pool] = await tx.update(airdropCampaignSettingsTable)
        .set({
          testPoolUsdt: sql`${airdropCampaignSettingsTable.testPoolUsdt} - ${claim.testUsdtReward}`,
        })
        .where(and(
          eq(airdropCampaignSettingsTable.id, "main"),
          gte(airdropCampaignSettingsTable.testPoolUsdt, claim.testUsdtReward),
        ))
        .returning({ testPoolUsdt: airdropCampaignSettingsTable.testPoolUsdt });
      if (!pool) return { kind: "pool" as const };
    }

    const [reviewed] = await tx.update(airdropTaskClaimsTable)
      .set({ status: parsed.data.status, reviewedAt: new Date() })
      .where(and(
        eq(airdropTaskClaimsTable.id, claim.id),
        eq(airdropTaskClaimsTable.status, "pending"),
      ))
      .returning();
    if (!reviewed) return { kind: "missing" as const };

    if (parsed.data.status === "approved") {
      await tx.update(airdropUsersTable).set({
        points: sql`${airdropUsersTable.points} + ${claim.rewardPoints}`,
        testUsdtBalance: sql`${airdropUsersTable.testUsdtBalance} + ${claim.testUsdtReward}`,
      }).where(eq(airdropUsersTable.telegramId, claim.telegramId));
      await tx.insert(airdropActivityTable).values({
        telegramId: claim.telegramId,
        title: "Task approved",
        details: claim.taskTitle,
        kind: "task",
        amount: claim.rewardPoints,
      });
      if (claim.testUsdtReward > 0) {
        await tx.insert(airdropActivityTable).values({
          telegramId: claim.telegramId,
          title: "Test USDT reward",
          details: `${claim.taskTitle}. Test-only; not redeemable.`,
          kind: "test_reward",
          amount: claim.testUsdtReward,
        });
      }
    }

    const [user] = await tx.select()
      .from(airdropUsersTable)
      .where(eq(airdropUsersTable.telegramId, claim.telegramId))
      .limit(1);
    return {
      kind: "reviewed" as const,
      claim: reviewed,
      user,
    };
  });

  if (result.kind === "pool") {
    res.status(409).json({ error: "The test reward pool does not have enough balance." });
    return;
  }
  if (result.kind === "missing") {
    res.status(404).json({ error: "Pending claim not found." });
    return;
  }

  res.json(
    ReviewAirdropClaimResponse.parse({
      id: result.claim.id,
      taskId: result.claim.taskId,
      taskTitle: result.claim.taskTitle,
      telegramId: result.claim.telegramId,
      displayName: [result.user?.firstName, result.user?.lastName].filter(Boolean).join(" "),
      status: result.claim.status,
      rewardPoints: result.claim.rewardPoints,
      testUsdtReward: result.claim.testUsdtReward,
      claimedAt: result.claim.claimedAt,
    }),
  );
});

router.patch("/airdrop/admin/withdrawals/:withdrawalId", async (req, res): Promise<void> => {
  if (!(await adminAccount(req, res))) return;
  const params = ReviewAirdropWithdrawalParams.safeParse(req.params);
  const parsed = ReviewAirdropWithdrawalBody.safeParse(req.body);
  if (!params.success || !parsed.success) {
    res.status(400).json({ error: "Invalid withdrawal review." });
    return;
  }

  const result = await db.transaction(async (tx) => {
    const [reviewed] = await tx.update(airdropWithdrawalsTable)
      .set({ status: parsed.data.status, reviewedAt: new Date() })
      .where(and(
        eq(airdropWithdrawalsTable.id, params.data.withdrawalId),
        eq(airdropWithdrawalsTable.status, "pending_test"),
      ))
      .returning();
    if (!reviewed) return { kind: "missing" as const };

    if (parsed.data.status === "rejected") {
      await tx.update(airdropUsersTable).set({
        testUsdtBalance: sql`${airdropUsersTable.testUsdtBalance} + ${reviewed.amount}`,
      }).where(eq(airdropUsersTable.telegramId, reviewed.telegramId));
      await tx.insert(airdropActivityTable).values({
        telegramId: reviewed.telegramId,
        title: "Test request rejected",
        details: "Test balance returned. No payment was made.",
        kind: "withdrawal",
        amount: reviewed.amount,
      });
    } else {
      await tx.insert(airdropActivityTable).values({
        telegramId: reviewed.telegramId,
        title: "Test request reviewed",
        details: "Marked approved in the test ledger. No USDT was transferred.",
        kind: "withdrawal",
        amount: -reviewed.amount,
      });
    }

    const [user] = await tx.select()
      .from(airdropUsersTable)
      .where(eq(airdropUsersTable.telegramId, reviewed.telegramId))
      .limit(1);
    return { kind: "reviewed" as const, withdrawal: reviewed, user };
  });

  if (result.kind === "missing") {
    res.status(404).json({ error: "Pending test request not found." });
    return;
  }
  res.json(
    ReviewAirdropWithdrawalResponse.parse({
      id: result.withdrawal.id,
      telegramId: result.withdrawal.telegramId,
      displayName: [result.user?.firstName, result.user?.lastName].filter(Boolean).join(" "),
      amount: result.withdrawal.amount,
      walletAddress: result.withdrawal.walletAddress,
      status: result.withdrawal.status,
      createdAt: result.withdrawal.createdAt,
      testMode: true,
    }),
  );
});

router.patch("/airdrop/admin/settings", async (req, res): Promise<void> => {
  if (!(await adminAccount(req, res))) return;
  const parsed = UpdateAirdropSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid campaign settings." });
    return;
  }
  const [settings] = await db.update(airdropCampaignSettingsTable)
    .set(parsed.data)
    .where(eq(airdropCampaignSettingsTable.id, "main"))
    .returning();
  if (!settings) {
    res.status(503).json({ error: "Campaign settings are not initialized." });
    return;
  }
  res.json(
    UpdateAirdropSettingsResponse.parse({
      testMode: true,
      testPoolUsdt: settings.testPoolUsdt,
      minimumWithdrawal: settings.minimumWithdrawal,
      paymentIntegrationReady: false,
    }),
  );
});

export default router;
