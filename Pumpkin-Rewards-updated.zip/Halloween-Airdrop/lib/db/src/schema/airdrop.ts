import {
  boolean,
  date,
  index,
  integer,
  numeric,
  pgTable,
  primaryKey,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const airdropUsersTable = pgTable(
  "airdrop_users",
  {
    telegramId: text("telegram_id").primaryKey(),
    firstName: text("first_name").notNull(),
    lastName: text("last_name"),
    username: text("username"),
    languageCode: text("language_code"),
    referralCode: text("referral_code").notNull(),
    referredBy: text("referred_by"),
    points: integer("points").notNull().default(0),
    testUsdtBalance: numeric("test_usdt_balance", {
      precision: 18,
      scale: 6,
      mode: "number",
    }).notNull().default(0),
    walletAddress: text("wallet_address"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("airdrop_users_referral_code_uq").on(table.referralCode),
    index("airdrop_users_referred_by_idx").on(table.referredBy),
  ],
);

export const airdropTasksTable = pgTable(
  "airdrop_tasks",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull().unique(),
    description: text("description").notNull().default(""),
    taskType: text("task_type").notNull(),
    targetUrl: text("target_url"),
    rewardPoints: integer("reward_points").notNull().default(0),
    testUsdtReward: numeric("test_usdt_reward", {
      precision: 18,
      scale: 6,
      mode: "number",
    }).notNull().default(0),
    active: boolean("active").notNull().default(false),
    dailyLimit: boolean("daily_limit").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
);

export const airdropTaskClaimsTable = pgTable(
  "airdrop_task_claims",
  {
    id: serial("id").primaryKey(),
    telegramId: text("telegram_id")
      .notNull()
      .references(() => airdropUsersTable.telegramId, { onDelete: "cascade" }),
    taskId: integer("task_id")
      .notNull()
      .references(() => airdropTasksTable.id, { onDelete: "cascade" }),
    taskTitle: text("task_title").notNull(),
    status: text("status").notNull(),
    rewardPoints: integer("reward_points").notNull(),
    testUsdtReward: numeric("test_usdt_reward", {
      precision: 18,
      scale: 6,
      mode: "number",
    }).notNull().default(0),
    claimDay: date("claim_day", { mode: "string" }).notNull(),
    claimedAt: timestamp("claimed_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  },
  (table) => [
    uniqueIndex("airdrop_task_claims_daily_uq").on(
      table.telegramId,
      table.taskId,
      table.claimDay,
    ),
    index("airdrop_task_claims_status_idx").on(table.status),
  ],
);

export const airdropActivityTable = pgTable(
  "airdrop_activity",
  {
    id: serial("id").primaryKey(),
    telegramId: text("telegram_id")
      .notNull()
      .references(() => airdropUsersTable.telegramId, { onDelete: "cascade" }),
    title: text("title").notNull(),
    details: text("details").notNull().default(""),
    kind: text("kind").notNull(),
    amount: numeric("amount", { precision: 18, scale: 6, mode: "number" })
      .notNull()
      .default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("airdrop_activity_user_created_idx").on(table.telegramId, table.createdAt)],
);

export const airdropWithdrawalsTable = pgTable(
  "airdrop_withdrawals",
  {
    id: serial("id").primaryKey(),
    telegramId: text("telegram_id")
      .notNull()
      .references(() => airdropUsersTable.telegramId, { onDelete: "cascade" }),
    amount: numeric("amount", { precision: 18, scale: 6, mode: "number" }).notNull(),
    walletAddress: text("wallet_address").notNull(),
    status: text("status").notNull().default("pending_test"),
    testMode: boolean("test_mode").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  },
  (table) => [
    index("airdrop_withdrawals_user_created_idx").on(table.telegramId, table.createdAt),
    index("airdrop_withdrawals_status_idx").on(table.status),
  ],
);

export const airdropCampaignSettingsTable = pgTable(
  "airdrop_campaign_settings",
  {
    id: text("id").notNull(),
    testPoolUsdt: numeric("test_pool_usdt", {
      precision: 18,
      scale: 6,
      mode: "number",
    }).notNull().default(0),
    minimumWithdrawal: numeric("minimum_withdrawal", {
      precision: 18,
      scale: 6,
      mode: "number",
    }).notNull().default(1),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [primaryKey({ columns: [table.id] })],
);

export type AirdropUser = typeof airdropUsersTable.$inferSelect;
export type AirdropTask = typeof airdropTasksTable.$inferSelect;
export type AirdropTaskClaim = typeof airdropTaskClaimsTable.$inferSelect;
export type AirdropActivity = typeof airdropActivityTable.$inferSelect;
export type AirdropWithdrawal = typeof airdropWithdrawalsTable.$inferSelect;
export type AirdropCampaignSettings =
  typeof airdropCampaignSettingsTable.$inferSelect;
