# Halloween Airdrop

A Telegram Mini App for Halloween campaign tasks, referrals, wallets, and test-only USDT request simulations.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required secret: `TELEGRAM_BOT_TOKEN` — validates signed Telegram Mini App initData
- Admin allowlist: `TELEGRAM_ADMIN_IDS` — comma-separated numeric Telegram user IDs
- Optional: `TELEGRAM_BOT_USERNAME` — public bot username override for invite links
- `DATABASE_URL` is supplied by the Replit database environment

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/halloween-airdrop` — Telegram Mini App UI and routes
- `artifacts/api-server/src/routes/airdrop.ts` and `airdrop-admin.ts` — account and admin API
- `artifacts/api-server/src/lib/airdrop-auth.ts` — server-side Telegram initData validation
- `lib/db/src/schema/airdrop.ts` — account, task, referral, activity, and test withdrawal tables
- `lib/api-spec/openapi.yaml` — source of truth for API contracts

## Architecture decisions

- Every real account request verifies raw Telegram initData with the bot token; client profile fields are not trusted.
- USDT balances and withdrawals are permanently test-only in this version; no payment or chain transfer is configured.
- Social task claims remain pending until an administrator reviews them.
- Development preview access uses an explicitly labeled demo account and is disabled in production.

## Product

Users can view points and test balances, complete campaign tasks, share a referral link, save a TRC20 wallet address, request simulated withdrawals, and review account activity. Admins can manage tasks, set test rewards, review claims and requests, and manage the test pool.

## User preferences

The app must not present simulated balances or rewards as real or imply that a payout is guaranteed.

## Gotchas

- Production admin screens remain locked until the owner's Telegram user ID is listed in `TELEGRAM_ADMIN_IDS`.
- `TELEGRAM_BOT_USERNAME` is optional; the server can resolve the username through Telegram when a bot token is configured.
- A task with a USDT test reward can only credit users when the simulated pool has enough balance.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
